package com.overyourhead.merchant_orders.common.event;

import com.overyourhead.merchant_orders.MerchantOrdersMod;
import com.overyourhead.merchant_orders.common.MOConstants;
import com.overyourhead.merchant_orders.common.config.MOConfig;
import com.overyourhead.merchant_orders.common.player.PlayerOrderData;
import com.overyourhead.merchant_orders.common.sale.PlayerSaleData;
import com.overyourhead.merchant_orders.common.trade.TradePoolRegistry;
import com.overyourhead.merchant_orders.core.registry.MOBlocks;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.BasicItemListing;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.village.VillagerTradesEvent;
import net.neoforged.neoforge.event.village.WandererTradesEvent;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@EventBusSubscriber(modid = MerchantOrdersMod.MOD_ID, bus = EventBusSubscriber.Bus.GAME)
public final class CommonEvents {
    private static final int CATALOG_WARMUP_INTERVAL_TICKS = 1;
    private static final int CATALOG_BACKGROUND_CANDIDATES_PER_TICK = 2;
    private static final int CATALOG_URGENT_CANDIDATES_PER_TICK = 1;
    private static final int CATALOG_WARMUP_DELAY_TICKS = 60;
    private static final Map<UUID, CatalogWarmup> CATALOG_WARMUPS = new HashMap<>();

    private CommonEvents() {
    }

    @SubscribeEvent
    public static void onVillagerTrades(VillagerTradesEvent event) {
        TradePoolRegistry.capture(event);
    }

    @SubscribeEvent
    public static void onWandererTrades(WandererTradesEvent event) {
        event.getGenericTrades().add(new BasicItemListing(
                MOConfig.TERMINAL_PRICE.get(),
                new ItemStack(MOBlocks.ORDER_TERMINAL.get()),
                MOConfig.TERMINAL_MAX_USES.get(),
                10
        ));
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }

        CatalogWarmup warmup = CATALOG_WARMUPS.get(player.getUUID());
        if (warmup == null) {
            return;
        }
        if (player.tickCount % CATALOG_WARMUP_INTERVAL_TICKS != 0) {
            return;
        }
        try {
            if (warmup.currentBuild == null) {
                warmup.startNextBuild(player);
            }
            if (warmup.currentBuild != null
                    && warmup.currentBuild.step(warmup.currentUrgent
                            ? CATALOG_URGENT_CANDIDATES_PER_TICK
                            : CATALOG_BACKGROUND_CANDIDATES_PER_TICK)) {
                warmup.currentBuild = null;
                warmup.currentTier = -1;
            }
        } catch (RuntimeException exception) {
            CATALOG_WARMUPS.remove(player.getUUID());
            MerchantOrdersMod.LOGGER.debug("Stopped order catalog warmup for {}", player.getGameProfile().getName(), exception);
            return;
        }

        if (warmup.currentBuild == null && warmup.urgentTiers.isEmpty() && warmup.backgroundTiers.isEmpty()) {
            CATALOG_WARMUPS.remove(player.getUUID());
        }
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        if (event.getOriginal() instanceof ServerPlayer original && event.getEntity() instanceof ServerPlayer clone) {
            PlayerOrderData.copyPersistentData(original, clone);
            PlayerSaleData.copy(original, clone);
        }
    }

    public static void queueCatalogWarmup(ServerPlayer player) {
        long cycle = player.serverLevel().getGameTime() / MOConfig.catalogRefreshTicks();
        PlayerOrderData orderData = PlayerOrderData.load(player, cycle);
        int unlockedTier = MOConstants.unlockedTier(orderData.xp());
        int selectedTier = Math.min(orderData.selectedTier(), unlockedTier);

        CATALOG_WARMUPS.put(
                player.getUUID(),
                new CatalogWarmup(cycle, buildWarmupTiers(unlockedTier, selectedTier), CATALOG_WARMUP_DELAY_TICKS)
        );
    }

    public static void queueCatalogWarmup(ServerPlayer player, int priorityTier) {
        long cycle = player.serverLevel().getGameTime() / MOConfig.catalogRefreshTicks();
        PlayerOrderData orderData = PlayerOrderData.load(player, cycle);
        int unlockedTier = MOConstants.unlockedTier(orderData.xp());
        int selectedTier = Math.min(orderData.selectedTier(), unlockedTier);
        if (priorityTier < 0 || priorityTier > unlockedTier) {
            return;
        }

        CatalogWarmup warmup = CATALOG_WARMUPS.get(player.getUUID());
        if (warmup == null || warmup.catalogCycle != cycle) {
            warmup = new CatalogWarmup(cycle, buildWarmupTiers(unlockedTier, selectedTier), CATALOG_WARMUP_DELAY_TICKS);
            CATALOG_WARMUPS.put(player.getUUID(), warmup);
        }

        warmup.backgroundTiers.remove(priorityTier);
        warmup.urgentTiers.remove(priorityTier);
        if (!TradePoolRegistry.isCatalogCached(player.serverLevel(), player, priorityTier, cycle)) {
            warmup.pauseBackgroundBuild();
            warmup.urgentTiers.addFirst(priorityTier);
        }
    }

    private static ArrayDeque<Integer> buildWarmupTiers(int unlockedTier, int selectedTier) {
        ArrayDeque<Integer> tiers = new ArrayDeque<>();
        tiers.add(selectedTier);
        for (int tier = 0; tier <= unlockedTier; tier++) {
            if (tier != selectedTier) {
                tiers.add(tier);
            }
        }
        return tiers;
    }

    private static final class CatalogWarmup {
        private final long catalogCycle;
        private final ArrayDeque<Integer> urgentTiers = new ArrayDeque<>();
        private final ArrayDeque<Integer> backgroundTiers;
        private int delayTicks;
        private TradePoolRegistry.CatalogBuild currentBuild;
        private boolean currentUrgent;
        private int currentTier = -1;

        private CatalogWarmup(long catalogCycle, ArrayDeque<Integer> backgroundTiers, int delayTicks) {
            this.catalogCycle = catalogCycle;
            this.backgroundTiers = backgroundTiers;
            this.delayTicks = delayTicks;
        }

        private void startNextBuild(ServerPlayer player) {
            if (startNextBuild(player, urgentTiers, true)) {
                return;
            }
            if (delayTicks > 0) {
                delayTicks--;
                return;
            }
            startNextBuild(player, backgroundTiers, false);
        }

        private void pauseBackgroundBuild() {
            if (currentBuild == null || currentUrgent || currentTier < 0) {
                return;
            }

            backgroundTiers.remove(currentTier);
            backgroundTiers.addLast(currentTier);
            currentBuild = null;
            currentTier = -1;
        }

        private boolean startNextBuild(ServerPlayer player, ArrayDeque<Integer> tiers, boolean urgent) {
            while (!tiers.isEmpty()) {
                int tier = tiers.pollFirst();
                if (TradePoolRegistry.isCatalogCached(player.serverLevel(), player, tier, catalogCycle)) {
                    continue;
                }

                currentBuild = TradePoolRegistry.beginCatalogBuild(player.serverLevel(), player, tier, catalogCycle);
                currentUrgent = urgent;
                currentTier = tier;
                if (!currentBuild.step(0)) {
                    return true;
                }
                currentBuild = null;
                currentTier = -1;
            }
            return false;
        }
    }
}
